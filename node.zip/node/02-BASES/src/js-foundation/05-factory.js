
//const {getId} = require ('../plugins/get-id');
//const {getAge} = require('../plugins/get-age-plugins');
//const { getId, getAge } = require ('../plugins');

const buildMakePerson = ({getId, getAge}) => {
    return ( {name, birthdate}) => {

        return {
            id: getId(),
            name:name,
            birthdate:birthdate,
            //age: new Date().getFullYear() - new Date(birthdate).getFullYear(),
            age: getAge(birthdate),
        }
        
        }
}



// const obj = {name: 'Jarbir', birthdate: '1998-08-16'};
// const jarbir = buildPerson(obj);

// console.log(jarbir);
module.exports = {
    buildMakePerson,
}