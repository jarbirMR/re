


const getPokemonById = async (id) => {



  const url =`https://pokeapi.co/api/v2/pokemon/${id}`;

  const response = await fetch( url );
  const pokemon = await response.json();

  return pokemon.name;

//    return fetch( url )
//    .then ((resp)=> resp.json())
//    //.then ( () => {throw new Error ('pokemon no existe')})
//    .then ( (pokemon) => pokemon.name);

    //   response.json().then((pokemon) => {
       // console.log(pokemon.name);
     //  callback (pokemon.name);

       }


module.exports = getPokemonById;