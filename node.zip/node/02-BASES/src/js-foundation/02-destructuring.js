
//console.log(process.env);

const  {SHELL,COLOR} = process.env;

//console.table( {SHELL, COLOR});

const characteres = ['deadpool', 'spiderman', 'capitan america'];

const [ ,  , cp] = characteres;

//console.log(cp);