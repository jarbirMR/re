
const emailTemplate = `
<div>
  <h1>Hi {{name}}</h1>
  <p> Thank you for you order. </p>
  <p> Your order number is {{orderNumber}} </p>
</div>
`;
module.exports ={
    emailTemplate  
}

//console.log(emailTemplate); mpostrar en consola