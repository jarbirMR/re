
const { getId, getAge } = require ('./plugins');
//const {emailTemplate} = require ('./js-foundation/01-template');
//require('./js-foundation/02-destructuring');

//console.log(emailTemplate);

//const {getUserById } = require('./js-foundation/03-callbacks');
//const {getUserById } = require('./js-foundation/04-arrow')

const getPokemonById = require('./js-foundation/06-promises');

getPokemonById(4)
.then((pokemon) => console.log({pokemon}))
.catch ((err)=> console.log('por favor intente de nuevo'))
.finally(()=> console.log('Finalmente'));



//Referencia a la funcion factory y uso e inyeccion de dependencias
// const {buildMakePerson} = require('./js-foundation/05-factory')

// const makePerson = buildMakePerson({ getId , getAge});

// const obj = {name: 'Jarbir', birthdate: '1998-08-16'};

// const jarbir = makePerson(obj);

// console.log({jarbir});




// const id=1;

// //getUserById (id, function (error, user) {
//     getUserById (id, (error, user) => {
//     if (error) {
//      throw new Error(error);
//     } 
    
//     //getUserById(2, function (error, user2) {
//       //  getUserById(2, (error, user2)=>{
//        // if (error) {
//         // throw new Error(error);
//        // } 
//         // console.log({user, user2});
//         console.log(user);
//     //});

// });