// archivo de barril 

const {getId} = require ('../plugins/get-id');
const {getAge} = require('../plugins/get-age-plugins');

module.exports = {
 getId, 
 getAge,
}