const message =('Hola Mundo');

console.log(message);